﻿using System;

namespace DotNetAppTest
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Program opened, hit enter to close");
			Console.ReadLine();
		}
	}
}
